import { access, readdir, readFile } from 'node:fs/promises';
import { resolve, dirname, extname } from 'node:path';
import { existsSync, statSync } from 'node:fs';

const root = process.cwd();
const ignored = new Set(['dist','public','node_modules','.git']);
const required = ['index.html','design.css','brand-colors.css','interactions.js','image-fallbacks.js','assets','about','products','contact'];
for (const p of required) await access(resolve(root,p));

const files = [];
async function walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue;
    const p = resolve(dir, entry.name);
    if (entry.isDirectory()) await walk(p);
    else if (entry.isFile()) files.push(p);
  }
}
await walk(root);
const htmlFiles = files.filter(p => p.endsWith('.html'));
if (!htmlFiles.includes(resolve(root,'index.html'))) throw new Error('Root index.html missing');

function localPath(fromFile, raw, isLink=false) {
  if (!raw) return null;
  const value = raw.split('#')[0].split('?')[0];
  if (!value || /^(https?:|mailto:|tel:|data:|javascript:|#)/i.test(raw)) return null;
  let p = value.startsWith('/') ? resolve(root, decodeURIComponent(value.slice(1))) : resolve(dirname(fromFile), decodeURIComponent(value));
  if (isLink && existsSync(p) && statSync(p).isDirectory()) p = resolve(p,'index.html');
  return p;
}

const missing = [];
const attrRe = /<(img|script|link|a)\b[^>]*?\b(src|href)=["']([^"']+)["'][^>]*>/gi;
for (const file of htmlFiles) {
  const text = await readFile(file,'utf8');
  let m;
  while ((m = attrRe.exec(text))) {
    const tag=m[1].toLowerCase(), raw=m[3];
    const p=localPath(file, raw, tag==='a');
    if (p && !existsSync(p)) missing.push(`${file}: ${raw}`);
  }
}
const cssFiles=files.filter(p=>p.endsWith('.css'));
const urlRe=/url\(["']?([^"')]+)["']?\)/gi;
for (const file of cssFiles) {
  const text=await readFile(file,'utf8'); let m;
  while ((m=urlRe.exec(text))) {
    const p=localPath(file,m[1],false);
    if (p && !existsSync(p)) missing.push(`${file}: ${m[1]}`);
  }
}
if (missing.length) throw new Error(`Missing local references:\n${missing.join('\n')}`);
console.log(`Check passed: ${htmlFiles.length} HTML pages, ${files.length} source files, 0 missing local references.`);
