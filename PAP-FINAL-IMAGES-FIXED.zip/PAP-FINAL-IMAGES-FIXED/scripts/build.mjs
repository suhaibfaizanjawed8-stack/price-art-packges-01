import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const target = resolve(root, 'dist');
const items = [
  'index.html', 'design.css', 'brand-colors.css', 'interactions.js', 'image-fallbacks.js',
  'assets', 'about', 'blog', 'capabilities', 'case-studies', 'contact',
  'industries', 'innovation', 'privacy', 'products', 'quality', 'terms'
];

await rm(target, { recursive: true, force: true });
await mkdir(target, { recursive: true });
for (const item of items) {
  await cp(resolve(root, item), resolve(target, item), { recursive: true });
}
console.log('Build complete: final static website copied to dist/.');
